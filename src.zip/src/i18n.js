import { createI18n } from 'vue-i18n'


const messages = {
  en: {
    weather: {
      title: "Weather",
      metric: "Celsius",
      imperial: "Fahrenheit",
      temp: "Temperature",
      description: "Description",
      humidity: "Humidity",
      pressure: "Pressure",
      wind: "Wind",
      forecast: "5 Day Forecast",
      favorites: "Favorites",
      remove: "Remove",
    },
  },
  ru: {
    weather: {
      title: "Погода",
      metric: "Цельсий",
      imperial: "Фаренгейт",
      temp: "Температура",
      description: "Описание",
      humidity: "Влажность",
      pressure: "Давление",
      wind: "Ветер",
      forecast: "Прогноз на 5 дней",
      favorites: "Избранные города",
      remove: "Удалить",
    },
  },
};

const i18n = new createI18n({
  locale: "ru", // Язык по умолчанию
  messages,
});

export default i18n;