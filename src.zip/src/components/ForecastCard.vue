<template>
  <div class="forecast">
    <div v-for="(forecastItem, index) in forecast.list.slice(0, 5)" :key="index">
      <h4>{{ new Date(forecastItem.dt * 1000).toLocaleDateString() }}</h4>
      <p>{{ forecastItem.main.temp }} °{{ unit === "metric" ? "C" : "F" }}</p>
      <p>{{ forecastItem.weather[0].description }}</p>
      <img :src="`https://openweathermap.org/img/wn/${forecastItem.weather[0].icon}.png`" alt="icon" />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    forecast: Object,
    unit: String,
  },
};
</script>

<style scoped>
.forecast {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

.forecast div {
  margin: 10px;
  text-align: center;
}
</style>