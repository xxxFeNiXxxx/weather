<template>
  <div class="weather-card">
    <h3>{{ $t('weather.temp') }}: {{ weather.main.temp }} °{{ unit === 'metric' ? 'C' : 'F' }}</h3>
    <p>{{ $t('weather.description') }}: {{ weather.weather[0].description }}</p>
    <img :src="`https://openweathermap.org/img/wn/${weather.weather[0].icon}.png`" alt="icon" />
    <p>{{ $t('weather.humidity') }}: {{ weather.main.humidity }}%</p>
    <p>{{ $t('weather.pressure') }}: {{ weather.main.pressure }} hPa</p>
    <p>{{ $t('weather.wind') }}: {{ weather.wind.speed }} m/s, {{ getWindDirection(weather.wind.deg) }}</p>
  </div>
</template>

<script>
export default {
  props: {
    weather: Object,
    unit: String,
  },
  methods: {
    getWindDirection(deg) {
      const directions = [
        "Север", "Северо-восток", "Восток", "Юго-восток", "Юг", "Юго-запад", "Запад", "Северо-запад",
      ];
      const index = Math.floor((deg + 22.5) / 45) % 8;
      return directions[index];
    },
  },
};
</script>

<style scoped>
.weather-card {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.weather-card img {
  width: 50px;
  height: 50px;
  margin-top: 10px;
}

.weather-card p {
  font-size: 14px;
  margin: 5px 0;
}

.weather-card h3 {
  font-size: 20px;
  font-weight: bold;
  margin: 10px 0;
}
</style>