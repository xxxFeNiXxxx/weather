
import Vuex from "vuex";



export default new Vuex.Store({
  state: {
    weather: null,
    forecast: null,
    unit: "metric", // Цельсий по умолчанию
    favorites: JSON.parse(localStorage.getItem("favorites")) || [],
  },
  mutations: {
    setWeather(state, weather) {
      state.weather = weather;
    },
    setForecast(state, forecast) {
      state.forecast = forecast;
    },
    toggleUnit(state) {
      state.unit = state.unit === "metric" ? "imperial" : "metric";
    },
    addFavorite(state, city) {
      state.favorites.push(city);
      localStorage.setItem("favorites", JSON.stringify(state.favorites));
    },
    removeFavorite(state, city) {
      state.favorites = state.favorites.filter(c => c.name !== city.name);
      localStorage.setItem("favorites", JSON.stringify(state.favorites));
    },
  },
  actions: {
    async fetchWeather({ commit }, { lat, lon, unit, apiKey }) {
      const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${unit}`);
      const data = await response.json();
      commit('setWeather', data);
    },
    async fetchForecast({ commit }, { lat, lon, unit, apiKey }) {
      const response = await fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${unit}`);
      const data = await response.json();
      commit('setForecast', data);
    },
  },
});