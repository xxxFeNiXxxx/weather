<template>
  <div id="app">
    <weather-card v-if="weather" :weather="weather" :unit="unit" />
    <forecast-card v-if="forecast" :forecast="forecast" :unit="unit" />
  </div>
</template>

<script>
import WeatherCard from "./components/WeatherCard.vue";
import ForecastCard from "./components/ForecastCard.vue";

export default {
  name: "App",
  components: {
    WeatherCard,
    ForecastCard,
  },
  data() {
    return {
      weather: null,
      forecast: null,
      unit: "metric",
    };
  },
  mounted() {
    this.fetchWeather();
    this.fetchForecast();
  },
  methods: {
    async fetchWeather() {
      const apiKey = "4f4a4b2dd574bc9695561e480ac0ac72";
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=55.75&lon=37.62&appid=${apiKey}&units=${this.unit}`
        // `https://api.openweathermap.org/data/2.5/weather?lat=55.75&lon=37.62&appid=4f4a4b2dd574bc9695561e480ac0ac72&units=metric`
      );
      const data = await response.json();
      console.log(data)
      this.weather = data;
    },
    async fetchForecast() {
      const apiKey = "4f4a4b2dd574bc9695561e480ac0ac72";
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=55.75&lon=37.62&appid=${apiKey}&units=${this.unit}`
        // `https://api.openweathermap.org/data/2.5/forecast?lat=55.75&lon=37.62&appid=4f4a4b2dd574bc9695561e480ac0ac72&units=metric`
      );
      const data = await response.json();
      this.forecast = data;
    },
  },
};
</script>


<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.forecast {
  display: flex;
  justify-content: space-around;
}

.forecast div {
  margin: 10px;
}

button {
  background-color: red;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}
</style>